import os
from groq import Groq
# Keep your existing gemini or google.genai imports if you want to fall back to them

def generate_cv_content(prompt: str, system_instruction: str = "You are an expert CV writer.") -> str:
    """
    Generates tailored CV content based on a structured prompt.
    """
    # 1. Check for Groq API Key
    groq_key = os.environ.get("GROQ_API_KEY", "")
    
    if groq_key:
        # Initialize the Groq Client
        client = Groq(api_key=groq_key)
        
        # Structure the payload using a fast production model
        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",  # Using a larger model for high-quality CV text
            messages=[
                {"role": "system", "content": system_instruction},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3, # Keeps the layout and formatting choices structured and professional
        )
        return response.choices[0].message.content

    # 2. Fallback to Gemini if Groq key isn't present
    gemini_key = os.environ.get("GEMINI_API_KEY", "")
    if gemini_key:
        # ... Your existing Gemini generate_content code goes here ...
        pass
        
    raise ValueError("No active API keys found in the environment variables.")