import os
from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from groq import Groq

# 1. Create the FastAPI app instance so Uvicorn can find it!
app = FastAPI()

# 2. Initialize the Groq client
client = Groq(api_key=os.environ.get("GROQ_API_KEY", ""))

# 3. Decorate your endpoint function properly
@app.post("/generate")
def generate_cv_endpoint(request_data: dict):
    # Extract data from the incoming request payload (matching your test.py)
    job_title = request_data.get("job_title", "")
    company_name = request_data.get("company_name", "")
    job_description = request_data.get("job_description", "")
    candidate_background = request_data.get("candidate_background", "")
    tone = request_data.get("tone", "professional")

    # Construct a strong prompt for formatting
    system_instruction = "You are an expert ATS-optimized CV generator and career architect."
    user_prompt = f"""
    Generate a tailored, professional CV section for a candidate applying to the position of {job_title} at {company_name}.
    
    Target Job Description:
    {job_description}
    
    Candidate Background & Projects:
    {candidate_background}
    
    Tone of writeup: {tone}
    """

    # Define a generator function to handle the streaming chunks
    def groq_stream_generator():
        try:
            completion = client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[
                    {"role": "system", "content": system_instruction},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.3,
                stream=True  # Keeps streaming enabled
            )
            
            for chunk in completion:
                content = chunk.choices[0].delta.content
                if content:
                    yield content
                    
        except Exception as e:
            yield f"Error during streaming: {str(e)}"

    # Return the Streaming Response directly to your frontend/test client
    return StreamingResponse(groq_stream_generator(), media_type="text/plain")