import os
import streamlit as pd
import streamlit as st
from groq import Groq

# Import the prompt template logic you already wrote!
from prompts import SYSTEM_PROMPT, build_user_prompt

# 1. Page Configuration Setup
st.set_page_config(
    page_title="AI Cover Letter Architect",
    page_icon="💼",
    layout="centered"
)

# Custom Styling to give it a polished appearance
st.markdown("""
    <style>
    .main { max-width: 800px; }
    h1 { color: #1E3A8A; font-family: 'Helvetica Neue', sans-serif; }
    div.stButton > button:first-child {
        background-color: #2563EB;
        color: white;
        border-radius: 6px;
        width: 100%;
        font-weight: bold;
    }
    </style>
""", unsafe_allow_html=True)

st.title("💼 AI Cover Letter Architect")
st.caption("Generate tailored, ATS-optimized cover letters instantly powered by Llama 3.3.")
st.divider()

# 2. Sidebar configuration for API and Settings
with st.sidebar:
    st.header("⚙️ Configuration")
    # Tries to read from environment first, otherwise lets user paste it
    api_key = os.environ.get("GROQ_API_KEY", "")
    if not api_key:
        api_key = st.text_input("Enter Groq API Key:", type="password")
    else:
        st.success("API Key detected from environment!")
        
    st.subheader("Model Settings")
    tone = st.selectbox("Select Letter Tone:", ["confident", "formal", "conversational"], index=1)

# 3. Main Input Form Fields (matching your schemas)
st.subheader("📝 Application Details")

job_title = st.text_input("Target Job Title", placeholder="e.g., Web Developer")
company_name = st.text_input("Company Name", placeholder="e.g., Systems Ltd")

job_description = st.text_area(
    "Job Description", 
    placeholder="Paste the key responsibilities and requirements here...", 
    height=150
)

candidate_background = st.text_area(
    "Your Background / Experience Summary", 
    placeholder="Paste your resume highlights, key projects, or experience summary here...", 
    height=150
)

# 4. Handle Submission and Generation
if st.button("Generate Cover Letter ✨"):
    # Input validation checks
    if not api_key:
        st.error("Please provide a valid Groq API Key in the sidebar configuration.")
    elif not (job_title and company_name and job_description and candidate_background):
        st.warning("Please fill out all the input fields to generate your letter.")
    else:
        # Construct the user prompt using your exact logic
        user_prompt = build_user_prompt(
            job_title=job_title,
            company_name=company_name,
            job_description=job_description,
            candidate_background=candidate_background,
            tone=tone
        )
        
        st.subheader("✨ Generated Cover Letter")
        # Text container area where the stream will render
        output_area = st.empty()
        
        try:
            # Initialize the client
            client = Groq(api_key=api_key)
            
            # Request the streaming completion
            completion = client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.3,
                stream=True
            )
            
            # Stream the text chunks live into the UI container!
            full_response = ""
            for chunk in completion:
                content = chunk.choices[0].delta.content
                if content:
                    full_response += content
                    output_area.markdown(full_response)
                    
        except Exception as e:
            st.error(f"Generation Error: {e}")